# Terminal-Render
This is my python terminal rendering engine, It nativley uses .ptri files. (Just text files with a special format that makes them easy to use for rendering ascii art by making every line in the file the same length via padding the ends of shorter lines with spaces.)

When using ptri-format, you must already have any text file you wish to render with this engine have the filename extention ptri, if adding many files, I recommend using Power rename for windows or bulk rename utility for any os.

Note:
I am curently working on having an exe file to go along with future updates so reddit doesnt try to cancel me (https://www.reddit.com/r/github/i_am_new_to_github_and_i_have_lots_to_say/) I am probably not making any appimage or anything though because if you have linux you should be more than able to run a .py or use wine. (I regret to inform you that malwarebytes flagged it as spyware so I am not going to upload the exe file just in case this repo gets flagged.)
Currently the main file can only be run from the command line, when in the same directory as the file (i.e. [~/Terminal-Render/]$ python3 ./Terminal-Render.py)
